<?php
/**
 * Database Configuration
 * Update these values according to your MySQL setup
 */

return [
    'host' => 'localhost',
    'database' => 'u731797225_edutenant_lms',
    'username' => 'u731797225_lms',
    'password' => 'Lmshosted@2026',
    'charset' => 'utf8mb4',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];

